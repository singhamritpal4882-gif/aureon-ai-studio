AUREON AI STUDIO — QUICK START

FILES
- index.html: complete responsive luxury-style agency website.

BEFORE PUBLISHING
1. Open index.html in a browser and review it.
2. Replace every instance of "AUREON AI STUDIO" if you choose another brand.
3. Replace hello@yourdomain.com with an email address you control.
4. Update the service scope and prices so they accurately match what you can deliver.
5. Do not claim client results, testimonials, certifications or integrations you do not have.

FREE PUBLISHING WITH GITHUB PAGES
1. Sign in to GitHub and create a NEW PUBLIC repository named aureon-ai-studio.
2. Upload index.html to the repository's top/root level (not inside another folder).
3. Open repository Settings > Pages.
4. Under Build and deployment, choose Deploy from a branch.
5. Select branch main and folder /(root), then Save.
6. Wait for the Pages deployment to finish. Your public URL will be:
   https://YOUR-GITHUB-USERNAME.github.io/aureon-ai-studio/

CUSTOM DOMAIN
Optional. A custom domain costs money; the GitHub Pages subdomain above is free.

IMPORTANT
The contact button uses mailto and opens the visitor's email app. It is not a hosted contact form.
The pricing is indicative example pricing in USD. Confirm scope and delivery costs before taking payment.
If you are under 18, ask a parent/guardian to help with payment accounts, contracts and platform age requirements.
